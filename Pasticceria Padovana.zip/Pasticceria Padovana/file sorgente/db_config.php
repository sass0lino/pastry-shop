<?php
// configurazione delle credenziali del database.
// questo file viene ignorato da git grazie a gitignore per permettere a ogniuno di noi di avere le proprie credenziali locali
define('DB_HOST', 'localhost'); 
define('DB_NAME', 'gdelucch'); 
define('DB_USER', 'gdelucch'); 
define('DB_PASSWORD', 'uzooVoiTh8aib9ii');
?>